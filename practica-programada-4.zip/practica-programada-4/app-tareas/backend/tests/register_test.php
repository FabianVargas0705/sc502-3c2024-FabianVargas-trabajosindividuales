<?php
require('../register.php');

echo(userRegistry('user1@gmail.com', '123456', 'user1@gmail.com'));