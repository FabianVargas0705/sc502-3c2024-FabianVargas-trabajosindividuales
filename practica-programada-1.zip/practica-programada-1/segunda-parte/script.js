document.getElementById('form-agenda').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Cita reservada con éxito');
    window.location.href = 'index.html'; 
});